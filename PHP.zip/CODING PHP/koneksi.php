<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "db_oyaaa";

$koneksi = mysqli_connect($server , $username , $password ,$database);

?>