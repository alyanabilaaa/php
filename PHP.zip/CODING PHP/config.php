<?php

$sql_connection  = mysqli_connect("localhost" , "root" ,null, "db_oyaaa");

if ($sql_connection) {
	echo "CONNECTION BERJAYA";
}

?>