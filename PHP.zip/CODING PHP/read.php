<?php
require "koneksi.php";
$sql     = " SELECT * FROM table_oyaaa";
$execute = mysqli_query($koneksi , $sql);
?>





<!DOCTYPE html>
<html>
<head>
  <style>
table {
  border-collapse: collapse;
  width: 100%;
  background-color: mistyrose;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {background-color: pink;}
</style>
  <title>Read Php</title>
</head>
<body>
  <a href="create.php">Add</a>
  <table border="1" width="50%">
    <thead>
      <th>id</th>
      <th>nama</th>
      <th>kelas</th>
      <th>action</th>
    </thead>
    <?php while($result =  mysqli_fetch_assoc($execute))?>
    <tr>
      <td><?= $result['username'] ?></td>
      <td><?= $result['password'] ?></td>
      <td><?= $result['name'] ?></td>
       <td><?= $result['email'] ?></td>
      <td> 
        <a href="update.php?id=<?= $result['id'] ?>">Update</a>
         |
        <a href="delete.php?id=<?= $result['id'] ?>">Delete</a>
        </td>
    </tr>
 
  </table>

</body>
</html>